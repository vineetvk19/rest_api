// const fetch=require('node-fetch');
const axios=require('axios')
exports.resultController=function (req,res,next) {
    const user_number =req.body.user_number
    console.log(user_number)
    let user_data
    const url='http://randomuser.me/api/?results='+user_number;
    axios.get(`http://randomuser.me/api/?results=${user_number}`)
        .then(res=>{
            // console.log(res.data);
            user_data=res.data
            const total_user=res.data.results.length;
            let final_data=[]
            const nat=[]
            const natidiv=user_data.results.map((user)=>{
                if (!nat.includes(user.nat)){
                    nat.push(user.nat)
                }
            });
            for (let j=0;j<nat.length;j++){
                let f_0_30=0;
                let f_30_50=0;
                let f_50_up=0;
                let m_0_30=0;
                let m_30_50=0;
                let m_50_up=0;
                const agedis=user_data.results.map((user)=>{
                    if (user.gender == 'female' && user.nat==nat[j]) {
                        if(user.dob.age<=30){
                            f_0_30++;
                        }else{
                            if(user.dob.age>30 && user.dob.age<=50){
                                f_30_50++
                            }else{f_50_up++}
                        }
                    } else if(user.gender == 'male' && user.nat==nat[j]){
                        // male.push(user.dob.age);
                        if(user.dob.age<=30){
                            m_0_30++;
                        }else{
                            if(user.dob.age>30 && user.dob.age<=50){
                                m_30_50++
                            }else{m_50_up++}
                        }
                    }

                });
                final_data.push({
                    nat:nat[j],
                    f_0_30:f_0_30,
                    f_30_50:f_30_50,
                    f_50_up:f_50_up,
                    m_0_30:m_0_30,
                    m_30_50:m_30_50,
                    m_50_up:m_50_up,
                    total_user:total_user
                })
            }
            //
            // for(let i=0; i<female.length; i++){
            //     if(female[i]<=30){
            //         f_0_30++;
            //     }else{
            //         if(female[i]>30 && female[i]<=50){
            //             f_30_50++;
            //         }else{
            //             f_50_up++;
            //         }
            //     }
            // }
            // for(let i=0; i<male.length; i++){
            //     if(male[i]<=30){
            //         m_0_30++;
            //     }else{
            //         if(male[i]>30 && male[i]<=50){
            //             m_30_50++;
            //         }else{
            //             m_50_up++;
            //         }
            //     }
            // }
            console.log(nat);
            console.log(total_user);
            console.log(final_data);
            return final_data;
        }).then(data=>{
        res.render('result', {final_data: data});
    })
        .catch(err=>{
            console.log(err)
        })

}
